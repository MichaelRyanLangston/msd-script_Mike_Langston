extern bool run_tests(void);
